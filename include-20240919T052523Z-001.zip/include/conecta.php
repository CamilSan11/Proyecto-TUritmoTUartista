<?php
$Server = "localhost";
$User = "root";
$Pass = "";
$Bd = "musica";
$Conecta = new mysqli($Server,$User,$Pass,$Bd);
if($Conecta->connect_error){
    die("Conexion sin exito".$Conecta->connect_error);
}
else{
    echo "La conexion fue exitosa";

}

?>