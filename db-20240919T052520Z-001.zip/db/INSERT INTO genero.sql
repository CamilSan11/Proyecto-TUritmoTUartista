INSERT INTO musica.genero(ID_genero,nombre_genero,ID_artista)
VALUES
(NULL,'Pop','1'),
(NULL,'Indie-rock','2'),
(NULL,'rock','3'),
(NULL,'rock_en_español','5'),
(NULL,'death metal','5');
