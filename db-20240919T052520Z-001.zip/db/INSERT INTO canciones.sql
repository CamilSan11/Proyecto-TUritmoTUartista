INSERT INTO musica.canciones(ID_canciones,titulo,duracion,ID_artista,ID_genero,ID_album)
VALUES
(NULL,'Fine Line','6 minutos y 18 segundos','1','1','1'),
(NULL,'Algun dia','3 muinutos y 16 segundos','2','2','2'),
(NULL,'Debajo de tu piel','3 minutos y 31 segundos','3','3','3'),
(NULL,'The trooper','4 minutos y 12 segundos','4','4','4'),
(NULL,'Cant help falling in love','1961-03-23','5','5','5');