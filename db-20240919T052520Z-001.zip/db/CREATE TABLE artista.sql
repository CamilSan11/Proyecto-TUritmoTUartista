CREATE TABLE musica.artista(ID_artista INT AUTO_INCREMENT NOT NULL,
nombre_artista varchar(55)NOT NULL,
nacionalidad varchar(55) NOT NULL,
fecha_nac DATE NOT NULL,
ID_album INT NOT NULL,ID_canciones INT NOT NULL,PRIMARY KEY(ID_artista))ENGINE=InnoDB;
