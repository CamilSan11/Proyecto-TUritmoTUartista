CREATE TABLE musica.album(ID_album INT AUTO_INCREMENT NOT NULL,
titulo_Album varchar(55)NOT NULL,
n_canciones varchar(55) NOT NULL,
fecha_lanza DATE NOT NULL,
ID_artistas INT NOT NULL,
ID_canciones INT NOT NULL,
PRIMARY KEY(ID_album))ENGINE=InnoDB;