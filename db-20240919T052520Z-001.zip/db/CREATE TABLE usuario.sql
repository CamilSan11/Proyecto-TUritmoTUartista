CREATE TABLE musica.usuario(ID_Usuario INT AUTO_INCREMENT NOT NULL,
Username varchar(255) NOT NULL,
Telefono varchar(10) NOT NULL,
Email varchar(255),
 Password varchar(255),
 ID_genero INT NOT NULL,
PRIMARY KEY(ID_usuario))ENGINE=InnoDB;