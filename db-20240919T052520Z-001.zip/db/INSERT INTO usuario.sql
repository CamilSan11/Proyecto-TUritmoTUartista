INSERT INTO musica.usuario(ID_Usuario,Username,Telefono,Email,Password,ID_genero)
VALUES
(NULL,'marmar653','5533563292','marmartinez@gmail.com','55hkmar','1'),
(NULL,'angelal08','5512329843','angelalvarezz@gmail.com','angel34','2'),
(NULL,'lizvazquez05','5532092109','lizvaz@gmial.com','1223333','3'),
(NULL,'camill11','5520984291','camsandoval@gmail.com','109mili','4'),
(NULL,'chaxez54','5509214382','chavezz@gmail.com','17chavezvz1','5');
