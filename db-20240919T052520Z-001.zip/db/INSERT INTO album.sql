INSERT INTO musica.album(ID_album,titulo_Album,n_canciones,fecha_lanza,ID_artistas,ID_canciones)
VALUES
(NULL,'Fine Line','12 canciones','2019-12-13','1','1'),
(NULL,'Memoria futuro','10 canciones','2020-11-02','2','2'),
(NULL,'El silecio','14 canciones','1992-04-08','3','3'),
(NULL,'Piece of mind','9 canciones','1983-05-16','4','4'),
(NULL,'Blue hawaii','15 canciones','1961-03-23','5','5');