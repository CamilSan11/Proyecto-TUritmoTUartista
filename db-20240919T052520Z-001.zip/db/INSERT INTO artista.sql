INSERT INTO musica.artista(ID_artista,nombre_artista,nacionalidad,fecha_nac,ID_album,ID_canciones)
VALUES
(NULL,'Harry Styles','Reino Unido','1994-02-01','1','1'),
(NULL,'Siddhartha','Guadalajara','1977-08-25','2','2'),
(NULL,'Caifanes','Mexico','1988-01-02','3','3'),
(NULL,'Iron Maiden','Reino Unido','1975-09-07','4','4'),
(NULL,'Elvis Presley','Tupelo','1935-01-08','5','5');