CREATE TABLE musica.genero(ID_genero INT AUTO_INCREMENT NOT NULL,
nombre_genero varchar(55) NOT NULL,
ID_artista INT NOT NULL, PRIMARY KEY(ID_genero))ENGINE=InnoDB;