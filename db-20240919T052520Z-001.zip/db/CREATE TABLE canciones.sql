CREATE TABLE musica.canciones(ID_canciones INT AUTO_INCREMENT NOT NULL,
titulo varchar(55)NOT NULL,
duracion varchar(55) NOT NULL,
ID_artista INT NOT NULL,
ID_genero INT NOT NULL,
ID_album INT NOT NULL,
PRIMARY KEY(ID_canciones))ENGINE=InnoDB;
